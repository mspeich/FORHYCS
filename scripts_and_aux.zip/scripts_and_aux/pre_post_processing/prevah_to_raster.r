#-------------------------------------------------------------------------------
# FORHYCS: A spatially distributed model combining hydrology and forest dynamics
# Copyright (C) 2014-2018  Matthias Speich, Massimiliano Zappa, Marc
# Scherstjanoi, Heike Lischke

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
# This script reads a grid in the PREVAH/FORHYCS binary format and converts it
# into a *raster* object. If an error occurs, try increasing the value of 
# argument "n".

#	filename:	path of the file to be read (character)
#	datatype:	data type expected in the file (is always "numeric") (character)
#	n:			expected number of records in the file (must be at least as high as the actual number of records, otherwise error) (numeric)
#	size:		size of a record in bytes (numeric)
#-------------------------------------------------------------------------------

library(rgdal)


readPrevah <- function(filename,datatype="numeric",n=30000,size=4){

	# Open connection to file and read in binary data into a vector
to.read <- file(filename,"rb")
grid <- readBin(to.read,datatype,n=n,size=size)

# Separate actual data from metadata
data1d <- grid[13:length(grid)]


data1d[data1d==grid[6]] <- NA

# Bring the data in its actual shape (2D matrix). Order of rows and columns needs to be reversed
data2d<-matrix(rev(data1d),ncol=grid[2],nrow=grid[1])
data2d <- apply(data2d,2,rev)

x <- seq(grid[3],grid[3]+(grid[1]*grid[5])-grid[5],by=grid[5])
y <- seq(grid[4],grid[4]+(grid[2]*grid[5]-grid[5]),by=grid[5])

# print("X")
# print(x)
# print('Y')
# print(y)

datalist <- list()
datalist$x <- x
datalist$y <- y
datalist$z <- data2d
library(raster)
r <- raster(datalist)
projection(r) <- CRS("+proj=somerc +lat_0=46.95240555555556 +lon_0=7.439583333333333 +k_0=1 +x_0=600000 +y_0=200000 +ellps=bessel +towgs84=674.4,15.1,405.3,0,0,0,0 +units=m +no_defs")
	
	close(to.read)
	return(r)
}

