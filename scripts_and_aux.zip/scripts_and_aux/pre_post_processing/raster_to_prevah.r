#-------------------------------------------------------------------------------
# FORHYCS: A spatially distributed model combining hydrology and forest dynamics
# Copyright (C) 2014-2018  Matthias Speich, Massimiliano Zappa, Marc
# Scherstjanoi, Heike Lischke

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
# This script writes a *raster* object to the binary format required by PREVAH / 
# FORHYCS.

#	r: 			raster object to be written (raster)
#	filename:	path of the file to be written (character)
#	rcol:		number of columns of the raster - if NULL, number of columns is retrieved from the raster object (numeric)
#	rrow:		number of rows of the raster - if NULL, number of rows is retrieved from the raster object (numeric)
#	rxll:		bottom-left x coordinate of the raster - if NULL, retrieved from the raster object (numeric)
#	ryll:		bottom-left y coordinate of the raster - if NULL, retrieved from the raster object (numeric)
#	rgridsize:	length of cell size in meters - if NULL, retrieved from the raster object (numeric)
#	rnodat:		value to be used for NA (numeric)
#-------------------------------------------------------------------------------

library(sp)
library(rgdal)
library(raster)

writePrevah <- function(r,filename,rcol=NULL,rrow=NULL,rxll=NULL,ryll=NULL,rgridsize=NULL,rnodat=-9999.0){
	 
	 if(is.null(rcol)){
	 	rcol <- as.numeric(ncol(r))
	 }
	 
	 if(is.null(rrow)){
	 	rrow <- as.numeric(nrow(r))
	 }
	 
	 # Assumes that cells are always quadratic, i.e. same length in x and y directions
	 if(is.null(rgridsize)){
	 	rgridsize <- (extent(r)@xmax - extent(r)@xmin)/rcol
	 }
	 
	 # Coordinates in PREVAH files refer to center of cell, as opposed to R/raster (lower left corner)
	 if(is.null(rxll)){
	 	rxll <- extent(r)@xmin + (rgridsize*0.5)
	 }
	 
	 if(is.null(ryll)){
	 	ryll <- extent(r)@ymin + (rgridsize*0.5)
	 }
	
      vals <- getValues(r)
	
	# Replace NA's with selected placeholder value for No Data cells
	  vals[is.na(vals)] <- rnodat
	
	# Get data from raster as a 2D matrix
	  data2d <- matrix(vals,ncol=rcol,nrow=rrow)
	
	# Convert data to 1D vector
	  data1d <- as.vector(data2d)
	
	# Open connection to file
	  to.write <- file(filename,"wb")
	
	# Write metadata
	  writeBin(rcol,to.write,size=4)
	  writeBin(rrow,to.write,size=4)
	  writeBin(rxll,to.write,size=4)
	  writeBin(ryll,to.write,size=4)
	  writeBin(rgridsize,to.write,size=4)
	  writeBin(rnodat,to.write,size=4)
	
	# Write statistics
	  #writeBin(rep(0,6),to.write,size=4)
	  writeBin(as.numeric(sum(!is.na(vals))),to.write,size=4)
	  writeBin(min(vals,na.rm=TRUE),to.write,size=4)
	  writeBin(max(vals,na.rm=TRUE),to.write,size=4)
	  writeBin(sum(vals,na.rm=TRUE),to.write,size=4)
	  writeBin(mean(vals,na.rm=TRUE),to.write,size=4)
	  writeBin(sd(vals,na.rm=TRUE),to.write,size=4)
	  	
	# Write data vector
	  writeBin(data1d,to.write,size=4)
	  
	# Close file connection
	  close(to.write)
	
}

