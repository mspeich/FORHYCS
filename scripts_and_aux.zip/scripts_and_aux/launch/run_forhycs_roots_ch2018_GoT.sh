#!/bin/bash
#SBATCH --verbose



macchina=`uname -n`

ulimit -s unlimited

SWISS_DIR="/home/speichm/nfp61/run"

# Getting variables
ezg=$1
scen=$2
future=$3
ice=$4
SC_YN=$5
gopt=$6
tpswitch=$7
lcdyn=$8
glacswitch=$9
rootslag=${10}
dohmax=${11}
dolared=${12}
dosfc=${13}
dosmort=${14}
cdtol=${15}
doground=${16}
ghogyear=${17}
grsmin=${18}
readFH=${19}
writeFH=${20}
deltaT=${21}
deltaP=${22}

echo $tpswitch
echo $lcdyn
echo $glacswitch

#### define time range for experiment ####
fc_date=19710101#19751001
end_date=20991231
meteosource=ch2018 #ch6109 #withrhires

#### creating name of model run ####
#RUN_NAME=${scen}_${future}_${ice}_${tpswitch}_LC${lcdyn}_gt${glacswitch}_hmax${dohmax}_la${dolared}_sfc${dosfc}_smort${dosmort}_dt${cdtol}_gh${doground}_${ghogyear}
RUN_NAME=ch2018_${scen}
#RUN_NAME=${tpswitch}_LC${lcdyn}_gt${glacswitch}_t${deltaT}_p${deltaP}

#### setup additionam date options needed ####
eyyyy=${end_date:0:4}
emm=${end_date:4:2}
edd=${end_date:6:2}

ini_date=${fc_date}

syyyy=${ini_date:0:4}
smm=${ini_date:4:2}
sdd=${ini_date:6:2}
lyyyy=`expr $syyyy + 1`

START_DATE="${sdd} ${smm} ${syyyy}"
SWITCH_DATE=${end_date}24

END_DATE="${edd} ${emm} ${eyyyy} 24"
echo $START_DATE
echo $END_DATE
echo $SWITCH_DATE

#### Old stuff to start the run, don't worry about this - calibration Y/N (R for routing only) and calibration settings ####

CALI="N"
BASIC_CTRL_FILE="rhb.ini"
NUM_PAIRS=9
NUM_ITER=5

#### define directories ####

BASE_DIR=${SWISS_DIR}

cd ${SWISS_DIR}/scripts

INP_DIR=${BASE_DIR}/prevah2d/inp
RUN_DIR=${BASE_DIR}/prevah2d/run

mkdir $INP_DIR/${RUN_NAME}
mkdir $RUN_DIR/${RUN_NAME}

#### path to PREVAH binary ####
#PREVAH=${SWISS_DIR}/bin/prevah2dlinuxhera_imet.out  # No Forhycs
#PREVAH=${SWISS_DIR}/bin/forhycs_mpi_roots.out  #Forhycs
PREVAH=${SWISS_DIR}/bin/forhycs_mpi.out  #Forhycs

#### catchments for which to run the simulation ####
ezg_c=0

     IDH_DIR=${BASE_DIR}/prevah2d/grids
     GKW_DIR=${BASE_DIR}/prevah2d/grids
     cp /home/speichm/nfp61/run/meteo/grid2grid.xyz ${BASE_DIR}/prevah2d/grids/${ezg}/${ezg}-grid2grid.xyz

      #MEO_DIR=${SWISS_DIR}/meteo/${meteosource}/Full/
      MEO_DIR=${SWISS_DIR}/meteo/${meteosource}/${scen}/Full/

      EZG_NUM=${gebiete_nr[ezg_c]}
      OUT_DIR=${SWISS_DIR}/${RUN_NAME}/
      mkdir ${OUT_DIR}
      OUT_DIR=${SWISS_DIR}/${RUN_NAME}/${ezg}/
      mkdir ${OUT_DIR}
      rm -r ${OUT_DIR}
      mkdir ${OUT_DIR}
      mkdir ${OUT_DIR}/states
      mkdir ${OUT_DIR}/treemig
      mkdir ${OUT_DIR}/treemig/C
      mkdir ${OUT_DIR}/treemig/E
      mkdir ${OUT_DIR}/treemig/G  # Grids
      mkdir ${OUT_DIR}/treemig/P
      mkdir ${OUT_DIR}/treemig/R
      mkdir ${OUT_DIR}/treemig/dist

      # Copy TreeMig parameter files to the copy of TreeMig folder created in the current run directory
      # Hard-coded for now because lazy
      # TODO: which is the real stockability file?

      echo ${OUT_DIR}

      #cp /home/speichm/nfp61/run/TreeMig/E/treestate_tm_remund.txt ${OUT_DIR}/treemig/E/treestate.txt
      #cp /home/speichm/nfp61/run/TreeMig/E/hydrostate_tm_remund.txt ${OUT_DIR}/treemig/E/hydrostate.txt
      #cp /home/speichm/nfp61/run/TreeMig/E/treestate_tm_bek.txt ${OUT_DIR}/treemig/E/treestate.txt
      #cp /home/speichm/nfp61/run/TreeMig/E/hydrostate_tm_bek.txt ${OUT_DIR}/treemig/E/hydrostate.txt
      cp /home/speichm/nfp61/run/TreeMig/E/bougabouga.txt ${OUT_DIR}/treemig/E/bougabouga.txt
      cp /home/speichm/nfp61/run/TreeMig/E/treestateGoT200_1972.txt ${OUT_DIR}/treemig/E/treestateGoT200_1972.txt
      cp /home/speichm/nfp61/run/TreeMig/E/hydrostateGoT200_1972.txt ${OUT_DIR}/treemig/E/hydrostateGoT200_1972.txt
      cp /home/speichm/nfp61/run/TreeMig/listOfCtrlPars.txt ${OUT_DIR}/treemig/listOfCtrlPars.txt
      cp /home/speichm/nfp61/run/TreeMig/newdispkernels.txt ${OUT_DIR}/treemig/newdispkernels.txt
      cp /home/speichm/nfp61/run/TreeMig/C/Tst1100_2.3 ${OUT_DIR}/treemig/C/Tst1100_2.3
      cp /home/speichm/nfp61/run/TreeMig/E/bc_goP.txt ${OUT_DIR}/treemig/E/bc_goP.txt
      #cp /home/speichm/nfp61/run/TreeMig/E/bc_goT.txt ${OUT_DIR}/treemig/E/bc_goT.txt
      #cp /home/speichm/nfp61/bioclim/GoT200/out/bioclim_t${deltaT}_p${deltaP}.txt ${OUT_DIR}/treemig/E/bc_goT.txt
      cp /home/speichm/nfp61/bioclim/GoT200/bek/bioclim_t${deltaT}_p${deltaP}.txt ${OUT_DIR}/treemig/E/bc_goT.txt
      cp /home/speichm/nfp61/run/TreeMig/E/GoT200_stock.txt ${OUT_DIR}/treemig/E/GoT200_stock.txt.txt
      cp /home/speichm/nfp61/run/TreeMig/E/stock_gougra.txt ${OUT_DIR}/treemig/E/stock_gougra.txt
      cp /home/speichm/nfp61/run/TreeMig/E/GoT200_state.txt ${OUT_DIR}/treemig/E/GoT200_state.txt
      cp /home/speichm/nfp61/run/TreeMig/P/TreePars1.7.txt ${OUT_DIR}/treemig/P/TreePars1.7.txt


      STAT_DIR=${OUT_DIR}/states/
      INP_FILE=${SWISS_DIR}/prevah2d/inp/${RUN_NAME}/${ezg}.inp
      RUN_FILE=${SWISS_DIR}/prevah2d/run/${RUN_NAME}/${ezg}.run
      GLAC_FILE=${SWISS_DIR}/prevah2d/inp/${RUN_NAME}/${ezg}.glac
      GRID_FILES=${GKW_DIR}/${ezg}/${ezg}
      IDH_FILE=${IDH_DIR}/${ezg}/${ezg}.idh
      EFF_SCRIPT=${EFF_DIR}/${ezg}.effs

      SC_FILE=${SWISS_DIR}/scenarios/basins/${ezg}/${ezg}_${scen}.${future} # Put here the link to the scenario control file

      echo ${ezg}

      cd ${SWISS_DIR}/scripts
      #### prepare INP-Files ####
      cp ${INP_DIR}/orig/${ezg}.inp.orig ${INP_FILE}.tmp
      cp ${INP_DIR}/orig/${ezg}.glac ${GLAC_FILE}

      perl -pi -e 's/^(<-- input common settings -->)/$1."\n".`cat \/home\/speichm\/nfp61\/run\/prevah2d\/inp\/orig\/common_settings_2014 `/e' ${INP_FILE}.tmp

      #### get line number of the output definition ####
      LINE_NUM=`grep -n \#OUTPUT_DIR\# ${INP_FILE}.tmp | cut -f1 -d:`

      echo $LINE_NUM

      echo ${MEO_DIR}

      sed -e "s/#START_DATE#/${START_DATE}/" \
      -e "s/#END_DATE#/${END_DATE}/g" \
      -e "s/#EZG#/${ezg}/g" \
      -e "s%#GRID_FILES#%${GRID_FILES}%" \
      -e "s%#STATE_DIR#%${STAT_DIR}%" \
      -e "s%#METEO_DIR#%${MEO_DIR}%" \
      -e "s%#OUTPUT_DIR#%${OUT_DIR}%" \
      -e "s%#IDH_FILE#%${IDH_FILE}%" \
      -e "s%#ICE#%${ice}%" \
      -e "s%#EFF_SCRIPTS#%${EFF_SCRIPT}%" \
      -e "s%#ROUTING_DIR#%${ROU_DIR}%" \
      -e "s/<-- input common settings -->//" \
      -e "s%#EZG_NUM#%${EZG_NUM}%" \
      -e "s%#RUN_NAME#%${RUN_NAME}%" \
      -e "s%#SCYN#%${SC_YN}%" \
      -e "s%#SCFILE#%${SC_FILE}%" \
      -e "s%#DELTAT#%${deltaT}%" \
      -e "s%#DELTAP#%${deltaP}%" \
      -e "s%#TPSWITCH#%${tpswitch}%" \
      -e "s%#LCDYN#%${lcdyn}%" \
      -e "s%#GLACSWITCH#%${glacswitch}%" \
      -e "s%#ROOTSLAG#%${rootslag}%" \
      -e "s%#DOHMAX#%${dohmax}%" \
      -e "s%#DOLARED#%${dolared}%" \
      -e "s%#DOSFC#%${dosfc}%" \
      -e "s%#DOSMORT#%${dosmort}%" \
      -e "s%#CDTOL#%${cdtol}%" \
      -e "s%#DOGROUND#%${doground}%" \
      -e "s%#GHOGYEAR#%${ghogyear}%" \
      -e "s%#GRSMIN#%${grsmin}%" \
      -e "s%#READFH#%${readFH}%" \
      -e "s%#WRITEFH#%${writeFH}%" \
      ${INP_FILE}.tmp > ${INP_FILE}

      rm ${INP_FILE}.tmp

      #### prepare RUN-Files ####
      cp ${RUN_DIR}/orig/${ezg}.run.orig ${RUN_FILE}.tmp

      perl -pi -e 's/^(<-- input common settings -->)/$1."\n".`cat \/home\/speichm\/nfp61\/run\/prevah2d\/run\/orig\/runfile_common `/e' ${RUN_FILE}.tmp

      sed -e "s%#INP_FILE#%${INP_FILE}%" \
      -e "s%#CALI_LO#%${CALI}%" \
      -e "s%#BASIC_CTRL_FILE#%${BASIC_CTRL_FILE}%" \
      -e "s%#NUM_PAIRS#%${NUM_PAIRS}%" \
      -e "s%#NUM_ITER#%${NUM_ITER}%" \
      -e "s%#LINE_NUM#%${LINE_NUM}%" \
      -e "s%#SWITCH_DATE#%${SWITCH_DATE}%" \
      -e "s/<-- input common settings -->//" \
      ${RUN_FILE}.tmp > ${RUN_FILE}

      rm ${RUN_FILE}.tmp

      #### Start PREVAH ####

      cd ${OUT_DIR}
      ls ${RUN_FILE}
      #${PREVAH} ${RUN_FILE} > ${BASE_DIR}/${RUN_NAME}_${ezg}.log &
      # mpirun --mca orte_base_help_aggregate 0 -np $NSLOTS $PREVAH ${RUN_FILE} -limf -lm > ${BASE_DIR}/${RUN_NAME}_${ezg}.log &
      mpirun $PREVAH ${RUN_FILE} -limf -lm > ${BASE_DIR}/${RUN_NAME}_${ezg}.log &
      # srun --mpi=pmi2 -n $SLURM_NTASKS $PREVAH ${RUN_FILE} -limf -lm > ${BASE_DIR}/${RUN_NAME}_${ezg}.log &
      # srun --mpi=pmi2 $PREVAH ${RUN_FILE} -limf -lm > ${BASE_DIR}/${RUN_NAME}_${ezg}.log &
      cd ${SWISS_DIR}/scripts

      #### Downscaling further years ####

mkdir ${OUT_DIR}mm/
mkdir ${OUT_DIR}yyyy/

test_file_num=`ls -1 ${OUT_DIR}*stop* | wc -l`

while [ $test_file_num -le 0 ]; do
    mv  ${OUT_DIR}*mm.* ${OUT_DIR}mm/
    mv  ${OUT_DIR}${ezg}19*.* ${OUT_DIR}yyyy/
    mv  ${OUT_DIR}${ezg}20*.* ${OUT_DIR}yyyy/
    mv  ${OUT_DIR}${ezg}21*.* ${OUT_DIR}yyyy/
    sleep 600
    test_file_num=`ls -1 ${OUT_DIR}*stop* | wc -l`
done

wait

# cleaning up

mv  ${OUT_DIR}*mm.* ${OUT_DIR}mm/
mv  ${OUT_DIR}${ezg}19*.* ${OUT_DIR}yyyy/
mv  ${OUT_DIR}${ezg}20*.* ${OUT_DIR}yyyy/
mv  ${OUT_DIR}${ezg}21*.* ${OUT_DIR}yyyy/

# tar -czvf ${OUT_DIR}${ezg}_${RUN_NAME}__mm_results.tgz ${OUT_DIR}mm/
#
# rm -r ${OUT_DIR}mm/
# rm -r ${OUT_DIR}yyyy/
# rm -r ${OUT_DIR}states/
# rm ${OUT_DIR}*.q
# gzip ${OUT_DIR}*.tmp
# #rm ${OUT_DIR}*.pri
# rm ${OUT_DIR}*.std
# rm ${OUT_DIR}*.ht*
# rm ${OUT_DIR}*.log
# rm ${OUT_DIR}*.LOG
# rm ${OUT_DIR}fort*

exit
