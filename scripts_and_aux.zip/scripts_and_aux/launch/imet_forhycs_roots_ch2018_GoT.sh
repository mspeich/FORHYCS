#!/bin/bash

macchina=`uname -n`

ulimit -s unlimited

SWISS_DIR="/home/speichm/nfp61/run"

#### define time range for experiment ####


BASE_DIR=${SWISS_DIR}

cd ${SWISS_DIR}/scripts

# Coupling parameters PRtoTM,TMtoPR,prevahBC

tpswitchlist=(
#000
#001
#011
#011
#100
#101
#110
111
)

# Land cover change parameter
lcdynList=(
0
#1
#2
)

# Control parameter for glacier module
glacswitchlist=(
0
#1
)

gebiete=(
GoT200
)

rootslag=(
#5
30
)


chains=(
#CTRL_RUN_WSL_F
#SMHI-RCA-ECEARTH-EUR44-RCP45
#DMI-HIRHAM-ECEARTH-EUR11-RCP45
CLMCOM-CCLM4-HADGEM-EUR44-RCP85
)

gridgrid_del=(
C
)


scen_met=(
T #C #N  #
)

o_scen_ice=(g00 )

scen_ice=(g73 )

delta_sleep=(
1
)


yyyy=(
2021
)

dT=(
0
#2
#4
#6
)

dP=(
#-10
0
#10
)


dohmax=(
#0
1
)

dolared=(
0
#1
)

dosfc=(
#0
1
)

dosmort=(
#0
1
)

cdtol=(
#1
2
)

doground=(
0
#1
)

ghogyear=(
2006
#2007
#1981
#2005
#2003
)

# GRSMIN is no longer used. For now, it is "recycled" to control CO2 effect
# on stomatal regulation. This is a quick fix because I'm too lazy to change
# the rest of the scripts for now.
grsmin=(
#0
1
#180
#500
)

readFH=(
#0
1
)

writeFH=(
0
#1
)


#### catchments for which to run the simulation ####



cd ${SWISS_DIR}/scripts/runlogs/
for glacswitch in ${glacswitchlist[*]} ;do
for lcdyn in ${lcdynList[*]} ;do
for tpswitch in ${tpswitchlist[*]} ;do
for ezg in ${gebiete[*]} ;do
mscen=0
for scen in ${chains[*]} ;do

future=${yyyy[$mscen]}
gsleep=${delta_sleep[$mscen]}
ice=${scen_ice[$mscen]}
cp_ice=${o_scen_ice[$mscen]}
gopt=${gridgrid_del[$mscen]}
scenyn=${scen_met[$mscen]}

for deltaT in ${dT[*]} ;do
for deltaP in ${dP[*]} ;do

echo $lcdyn

test_file_num=`qstat | wc -l`
echo $test_file_num
while [ $test_file_num -gt 80 ]; do
    sleep 3600
test_file_num=`qstat | wc -l`
echo $test_file_num
done

date
echo $gsleep
sleep $gsleep

cd ${SWISS_DIR}/prevah2d/grids
cp ${SWISS_DIR}/prevah2d/grids/${ezg}/${ezg}.${cp_ice} ${SWISS_DIR}/prevah2d/grids/${ezg}/${ezg}.${ice}
cp ${SWISS_DIR}/prevah2d/grids/${ezg}/${ezg}-ela*_3.bin ${SWISS_DIR}/prevah2d/grids
rename _3.bin .bin *
mv ${SWISS_DIR}/prevah2d/grids/${ezg}-ela*.bin ${SWISS_DIR}/prevah2d/grids/${ezg}/
cd ${SWISS_DIR}/prevah2d/grids/${ezg}
rm *.wgri*
rm *.rgri*
cd ${SWISS_DIR}/scripts/runlogs/

RUN_NAME=ch2018_${scen}
#RUN_NAME=${tpswitch}_LC${lcdyn}_gt${glacswitch}_t${deltaT}_p${deltaP}


# Submit a job
#qsub -q main.q -N ${ezg}_${future}_${scen}_${tpswitch}_${lcdyn}_${rootslag} ${SWISS_DIR}/scripts/run_forhycs_roots_mpi.sh $ezg $scen $future $ice $scenyn $gopt $tpswitch $lcdyn $glacswitch $rootslag $dohmax $dolared $dosfc $dosmort $cdtol $doground $ghogyear $grsmin $readFH $writeFH
sbatch --ntasks 20 --cpus-per-task 1 --time 08:00:00 --mem-per-cpu 2048 -J${RUN_NAME} ${SWISS_DIR}/scripts/run_forhycs_roots_ch2018_GoT.sh $ezg $scen $future $ice $scenyn $gopt $tpswitch $lcdyn $glacswitch $rootslag $dohmax $dolared $dosfc $dosmort $cdtol $doground $ghogyear $grsmin $readFH $writeFH $deltaT $deltaP
#sbatch --ntasks 20 --time 05:00:00 -J${RUN_NAME} ${SWISS_DIR}/scripts/run_forhycs_roots_future.sh $ezg $scen $future $ice $scenyn $gopt $tpswitch $lcdyn $glacswitch $rootslag $dohmax $dolared $dosfc $dosmort $cdtol $doground $ghogyear $grsmin $readFH $writeFH $deltaT $deltaP

# Just Submit
#sh ${SWISS_DIR}/scripts/run_6109_swiss_forhycs.sh $ezg $scen $future $ice $scenyn $gopt  $tpswitch &
#exit
sleep 300

done
done
let "mscen += 1"
done
done
done
done
done
